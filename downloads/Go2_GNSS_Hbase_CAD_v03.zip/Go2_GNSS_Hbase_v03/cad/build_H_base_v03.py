"""Go2 H-base with four integral legs, concept v0.3 (millimetres).

NOT A MANUFACTURING RELEASE. Only the 58-mm rail centre spacing and use
of M4 fastening come from the supplied Unitree interface drawing.
The user confirmed the M10 installation interface as an 11-mm clearance
hole and retained the four existing inner mounting holes (nine holes total).
No internal thread is modelled or specified. Other adaptation and production
checks remain outstanding.

Requires CadQuery 2.7. Run:
  python build_H_base_v03.py
  python build_H_base_v03.py --params parameters.json
Outputs overwrite this script's directory; preserve revisions separately.
"""
from pathlib import Path
import argparse
import json
import math
import cadquery as cq
from OCP.BRepAdaptor import BRepAdaptor_Surface

OUT=Path(__file__).resolve().parent
P={
    "revision":"v0.3",
    "status":"CONCEPT_REVIEW_ONLY_NOT_RELEASED_FOR_MANUFACTURE",
    "units":"mm",
    "source_confirmed":{"rail_slot_centre_spacing":58.0,"rail_fastener_thread":"M4"},
    "user_requested":{"plate_thickness":5.0,"leg_height_below_plate":15.0,
                      "central_interface_description":"M10 bolt passes through; nominal 11-mm hole",
                      "central_hole_diameter":11.0,"total_hole_count":9,
                      "preserve_existing_plate_holes":True},
    "base":{"length":100.0,"width":80.0,"thickness":5.0,
            "outer_corner_radius":4.0,"central_web_width":50.0,
            "side_cutout_height":28.0,"side_cutout_corner_radius":3.0},
    "integral_legs":{"count":4,"centres_x":[-38.0,38.0],
                     "centres_y":[-29.0,29.0],"outer_diameter":10.0,
                     "height_below_plate":15.0,"root_fillet_radius":2.0},
    "mounting_holes":{"diameter":4.5,"type":"THROUGH_CLEARANCE_NO_THREAD",
                      "through_plate_and_legs":True,"slots":False},
    "inner_mounting_pattern":{"hole_count":4,"hole_diameter":4.5,"square_pitch":32.0,
                              "type":"THROUGH_PLATE_ONLY_NO_THREAD",
                              "status":"USER_CONFIRMED_RETAIN_FOUR_INNER_HOLES"},
    "antenna_interface":{"central_hole_diameter":11.0,
                         "intended_bolt":"M10",
                         "interface_interpretation":"M10_BOLT_CLEARANCE_HOLE",
                         "confirmation_status":"USER_CONFIRMED_11MM_THROUGH_HOLE_NO_THREAD",
                         "thread":"NONE_MODELLED_OR_SPECIFIED",
                         "old_14mm_hole_replaced":True},
    "material_for_mass_estimate":{"name":"aluminium, grade not selected",
                                  "density_g_per_mm3":0.0027},
    "construction":"single continuous solid; integral machining intent, production process pending confirmation",
    "coordinate_system":"Z=0 at leg bottom bearing faces; plate underside Z=15; plate top Z=20. X longitudinal, Y across rails."
}

def rounded_plate(w,h,t,r):
    return cq.Workplane("XY").rect(w,h).extrude(t).edges("|Z").fillet(r)

def build(params):
    b,l,h=params["base"],params["integral_legs"],params["mounting_holes"]
    assert l["outer_diameter"]>h["diameter"]>0
    assert l["height_below_plate"]>l["root_fillet_radius"]>0
    points=[(x,y) for x in l["centres_x"] for y in l["centres_y"]]
    assert len(points)==l["count"]==4
    foot_h=l["height_below_plate"]
    total=foot_h+b["thickness"]
    part=rounded_plate(b["length"],b["width"],b["thickness"],b["outer_corner_radius"])
    # Open side cuts copy the v0.1 H-shaped plate outline, retaining the centre web.
    cut_width=(b["length"]-b["central_web_width"])/2+10.0
    cut_x=b["central_web_width"]/2+cut_width/2
    for x in (-cut_x,cut_x):
        cutter=rounded_plate(cut_width,b["side_cutout_height"],b["thickness"]+2,b["side_cutout_corner_radius"])
        part=part.cut(cutter.translate((x,0,-1)))
    part=part.translate((0,0,foot_h))
    legs=(cq.Workplane("XY").pushPoints(points)
          .circle(l["outer_diameter"]/2).extrude(foot_h))
    part=part.union(legs).clean()
    # Select only the four circular concave roots at the plate underside.
    root_edges=[]
    for edge in part.edges().vals():
        bbox=edge.BoundingBox()
        if (edge.geomType()=="CIRCLE" and
            abs(edge.radius()-l["outer_diameter"]/2)<1e-7 and
            abs(bbox.zmin-foot_h)<1e-7 and abs(bbox.zmax-foot_h)<1e-7):
            root_edges.append(edge)
    assert len(root_edges)==4, f"Expected 4 circular leg roots, got {len(root_edges)}"
    part=part.newObject(root_edges).fillet(l["root_fillet_radius"]).clean()
    # Round fixed holes replace the old slots and continue through the integral legs.
    cutters=(cq.Workplane("XY").workplane(offset=-1).pushPoints(points)
             .circle(h["diameter"]/2).extrude(total+2))
    part=part.cut(cutters).clean()
    # Restore the former 32-mm square mounting pattern, through the plate only.
    inner=params["inner_mounting_pattern"]
    inner_points=[(x,y) for x in (-inner["square_pitch"]/2,inner["square_pitch"]/2)
                  for y in (-inner["square_pitch"]/2,inner["square_pitch"]/2)]
    inner_cut=(cq.Workplane("XY").workplane(offset=foot_h-1).pushPoints(inner_points)
               .circle(inner["hole_diameter"]/2).extrude(b["thickness"]+2))
    part=part.cut(inner_cut)
    centre_cut=(cq.Workplane("XY").workplane(offset=foot_h-1)
                .circle(params["antenna_interface"]["central_hole_diameter"]/2)
                .extrude(b["thickness"]+2))
    part=part.cut(centre_cut).clean()
    return part,points,total

def validate(part,points,total):
    shape=part.val()
    assert shape.isValid(),"Invalid final solid"
    assert len(shape.Solids())==1,"The four legs must be integral with the plate"
    assert shape.Volume()>0
    b,l,h=P["base"],P["integral_legs"],P["mounting_holes"]
    torus_radii=[]
    for face in shape.Faces():
        surface=BRepAdaptor_Surface(face.wrapped)
        if face.geomType()=="TORUS":
            torus_radii.append(surface.Torus().MinorRadius())
    assert len(torus_radii)==4,("Expected four root blends",torus_radii)
    assert all(abs(r-l["root_fillet_radius"])<1e-7 for r in torus_radii)
    probes=[]
    for x,y in points:
        probe=(cq.Workplane("XY").workplane(offset=0.005).center(x,y)
               .circle((h["diameter"]-0.10)/2).extrude(total-0.01))
        overlap=shape.intersect(probe.val()).Volume()
        assert overlap<1e-7,("Blocked through-hole",x,y,overlap)
        probes.append({"xy_mm":[x,y],"probe_diameter_mm":h["diameter"]-0.10,
                       "probe_length_mm":total-0.01,"intersection_volume_mm3":overlap,
                       "through_clear":True})
    inner=P["inner_mounting_pattern"]
    inner_points=[(x,y) for x in (-inner["square_pitch"]/2,inner["square_pitch"]/2)
                  for y in (-inner["square_pitch"]/2,inner["square_pitch"]/2)]
    plate_checks=[]
    specs=[(x,y,inner["hole_diameter"],"inner_pattern") for x,y in inner_points]
    specs.append((0,0,P["antenna_interface"]["central_hole_diameter"],"centre_interface"))
    for x,y,diam,kind in specs:
        probe=(cq.Workplane("XY").workplane(offset=l["height_below_plate"]+0.005)
               .center(x,y).circle((diam-0.10)/2).extrude(b["thickness"]-0.01))
        overlap=shape.intersect(probe.val()).Volume()
        assert overlap<1e-7,("Blocked plate hole",x,y,overlap)
        plate_checks.append({"type":kind,"xy_mm":[x,y],"diameter_mm":diam,
                             "probe_length_mm":b["thickness"]-0.01,
                             "intersection_volume_mm3":overlap,"through_clear":True})
    # Verify the full circular boundaries of the nine actual holes in the top face.
    top_circles=[]
    for edge in part.faces(">Z").edges().vals():
        if edge.geomType()=="CIRCLE" and abs(edge.Length()-2*math.pi*edge.radius())<1e-5:
            c=edge.Center()
            top_circles.append({"xy_mm":[round(c.x,6),round(c.y,6)],
                                "diameter_mm":round(2*edge.radius(),6)})
    assert len(top_circles)==9,("Expected nine top holes",top_circles)
    expected=[(x,y,h["diameter"]) for x,y in points]+[(x,y,d) for x,y,d,_ in specs]
    for x,y,d in expected:
        assert any(abs(c["xy_mm"][0]-x)<1e-6 and abs(c["xy_mm"][1]-y)<1e-6
                   and abs(c["diameter_mm"]-d)<1e-6 for c in top_circles),("Wrong hole",x,y,d)
    bbox=shape.BoundingBox()
    return {"valid":True,"solid_count":1,
            "bounding_box_mm":[round(bbox.xlen,6),round(bbox.ylen,6),round(bbox.zlen,6)],
            "volume_mm3":round(shape.Volume(),6),
            "estimated_mass_g":round(shape.Volume()*P["material_for_mass_estimate"]["density_g_per_mm3"],3),
            "root_fillet":{"requested_radius_mm":l["root_fillet_radius"],
                           "applied":True,"verified_toroidal_faces":len(torus_radii),
                           "measured_minor_radii_mm":[round(r,6) for r in torus_radii]},
            "outer_through_hole_probes":probes,"plate_through_hole_probes":plate_checks,
            "actual_top_hole_circles":top_circles}

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    part,points,total=build(P)
    checks=validate(part,points,total)
    step_path=OUT/"H_base_integrated_v03.step"
    cq.exporters.export(part,str(step_path))
    cq.exporters.export(part,str(OUT/"H_base_integrated_v03.stl"),tolerance=0.12,angularTolerance=0.15)
    # Top face only: outline and holes. This cannot define the integral leg geometry.
    cq.exporters.export(part.faces(">Z"),str(OUT/"H_base_plan_profile_v03.dxf"))
    reopened=cq.importers.importStep(str(step_path)).val()
    assert reopened.isValid() and len(reopened.Solids())==1
    assert abs(reopened.Volume()-part.val().Volume())<0.001
    checks["step_roundtrip"]={"valid":True,"solid_count":1,
                              "volume_difference_mm3":abs(reopened.Volume()-part.val().Volume())}
    vertices,triangles=part.val().tessellate(0.15,0.20)
    mesh={"units":"mm","revision":P["revision"],"name":"H_base_integral_legs_v03",
          "category":"integral_base","color":[0.20,0.38,0.52],
          "coordinate_system":P["coordinate_system"],
          "vertices":[list(v.toTuple()) for v in vertices],
          "triangles":[list(t) for t in triangles]}
    b,l,h=P["base"],P["integral_legs"],P["mounting_holes"]
    summary={"revision":P["revision"],"status":P["status"],"units":"mm",
             "quantity_per_set":1,"part_types":1,"parameters":P,"geometry_checks":checks,
             "dimensions":{"leg_centres_mm":[list(p) for p in points],
                           "longitudinal_pitch_mm":l["centres_x"][1]-l["centres_x"][0],
                           "transverse_pitch_mm":l["centres_y"][1]-l["centres_y"][0],
                           "total_height_mm":total,"geometric_height_under_plate_mm":l["height_below_plate"],
                           "leg_wall_radial_thickness_mm":(l["outer_diameter"]-h["diameter"])/2},
             "purchase_hardware_pending":{"rail_M4_screws":4,"rail_M4_square_nuts":4,
                                          "screw_length":"TBD: 20-mm geometric stack plus washers, real nut engagement and bottom clearance",
                                          "nut_external_geometry":"MEASURE_ACTUAL_RAIL_AND_NUT",
                                          "antenna_fastener":"M10 bolt through the user-confirmed 11-mm clearance hole; no internal thread; bolt length and associated hardware to match actual antenna"},
             "limitations":[
                 "Concept geometry only; not a released manufacturing drawing.",
                 "Only 58-mm rail spacing and M4 fastening are source-confirmed. Plate thickness 5 mm and leg height 15 mm are user-requested; other dimensions are design values.",
                 "One integrated piece is intended; four loose spacers are not part of this revision.",
                 "The 15-mm geometric leg height is not verified clearance to the actual robot cover, fittings, hands or tools.",
                 f"The 32-mm mounting pattern is restored. The old 14-mm centre hole is replaced by a nominal {P['antenna_interface']['central_hole_diameter']:g}-mm hole.",
                 f"The centre hole has no internal thread. Interface interpretation: {P['antenna_interface']['interface_interpretation']}; status: {P['antenna_interface']['confirmation_status']}.",
                 "Fixed round holes remove the previous longitudinal slot adjustment.",
                 "Top-view DXF omits legs, root fillets and height; it is not a standalone cutting or manufacturing definition.",
                 "Material grade, surface finish, tolerances, dynamic loads, fatigue and tightening torque are unassigned.",
                 "Screw length and rail nut dimensions are not specified; original M4x10 arm screws cannot simply be reused.",
                 "No antenna, cable, robot shell or fasteners are included in interference validation.",
                 "Mass is CAD-volume estimation using provisional aluminium density, excluding hardware and antenna."
             ]}
    (OUT/"parameters.json").write_text(json.dumps(P,ensure_ascii=False,indent=2)+"\n")
    (OUT/"design_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
    (OUT/"preview_mesh.json").write_text(json.dumps(mesh,separators=(",",":"))+"\n")
    print(json.dumps({"geometry":checks,"files":[f.name for f in sorted(OUT.iterdir())]},ensure_ascii=False,indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--params",type=Path)
    args=parser.parse_args()
    if args.params:
        P=json.loads(args.params.read_text())
    main()
